package Assignment7;

public class Word {
	private String identifier = null;
	private String description = null;
	private String URI = null;
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getURI() {
		return URI;
	}
	public void setURI(String uri) {
		URI = uri;
	}

	
}
